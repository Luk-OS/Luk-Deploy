#!/bin/bash
# Script para descargar e instalar la última versión de pear-desktop (amd64)
# Compatible con Debian, Devuan, Ubuntu y derivados

set -e

REPO="https://github.com/pear-devs/pear-desktop/releases/latest"

echo "🔍 Obteniendo la última versión de pear-desktop..."
LATEST_URL=$(curl -Ls -o /dev/null -w %{url_effective} "$REPO")

VERSION=$(basename "$LATEST_URL")
echo "📦 Última versión detectada: $VERSION"

echo "🔗 Buscando el paquete .deb para amd64..."
DEB_URL=$(curl -s "$LATEST_URL" | grep -oP 'https://github.com/pear-devs/pear-desktop/releases/download/[^"]*_amd64\.deb' | head -n 1)

if [ -z "$DEB_URL" ]; then
    echo "❌ No se encontró ningún archivo .deb para amd64."
    exit 1
fi

DEB_FILE=$(basename "$DEB_URL")
echo "⬇️ Descargando paquete: $DEB_FILE"

wget -q --show-progress "$DEB_URL" -O "$DEB_FILE"

echo "🧩 Instalando pear-desktop y dependencias..."
sudo apt update
sudo apt install -y ./"$DEB_FILE"

echo "✅ Instalación completada correctamente."
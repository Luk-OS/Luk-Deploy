#!/bin/bash
# Script para desinstalar pear-desktop (YouTube Music)
# Compatible con Debian, Devuan, Ubuntu y derivados

set -e

echo "🧹 Iniciando desinstalación de pear-desktop..."

# Buscar el nombre exacto del paquete instalado (puede ser youtube-music o pear-desktop)
PKG=$(dpkg -l | grep -E 'youtube-music|pear-desktop' | awk '{print $2}' | head -n 1)

if [ -z "$PKG" ]; then
    echo "⚠️ No se encontró ninguna instalación de pear-desktop o youtube-music."
    exit 0
fi

echo "📦 Paquete detectado: $PKG"
echo "🗑️ Eliminando paquete y dependencias no necesarias..."

sudo apt remove -y "$PKG"
sudo apt autoremove -y
sudo apt clean

echo "🧽 Eliminando archivos residuales (si existen)..."
sudo rm -rf /opt/pear-desktop /opt/youtube-music /usr/share/applications/youtube-music.desktop ~/.config/pear-desktop ~/.config/youtube-music

echo "✅ pear-desktop (YouTube Music) desinstalado correctamente."